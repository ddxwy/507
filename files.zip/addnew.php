<?php
    include('conn.php');
 
    $heading=$_POST['heading'];
    $messages=$_POST['messages'];
    $user=$_POST['user'];
 
    mysqli_query($conn,"insert into topics (heading, messages, user) values ('$heading', '$messages', '$user')");
    header('location:index.php');
 
?>

Edit.php

<?php
    include('conn.php');
 
    $id=$_GET['id'];
 
    $heading=$_POST['heading'];
    $messages=$_POST['messages'];
    $user=$_POST['user'];
 
    mysqli_query($conn,"update topics set heading='$heading', messages='$messages', user='$user' where topicsid='$id'");
    header('location:index.php');
 
?>
