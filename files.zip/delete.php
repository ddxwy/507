<?php
    include('conn.php');
    $id=$_GET['id'];
    mysqli_query($conn,"delete from topics where topicsid='$id'");
    header('location:index.php');
 
?>
