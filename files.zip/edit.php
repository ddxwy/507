<?php
 
    include('conn.php');
    $id=$_GET['id'];
 
    $heading=$_POST['heading'];
    $messages=$_POST['messages'];
    $user=$_POST['user'];
 
    mysqli_query($conn,"update topics set heading='$heading', messages='$messages', user='$user' where topicsid='$id'");
    header('location:index.php');
 
?>
